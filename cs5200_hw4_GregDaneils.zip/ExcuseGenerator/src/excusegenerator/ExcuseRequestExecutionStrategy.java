/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package excusegenerator;

import AgentCommon.Agent;
import ExecutionStrategies.ExecutionStrategy;

/**
 *
 * @author gregor
 */
public class ExcuseRequestExecutionStrategy extends ExecutionStrategy{

    public ExcuseRequestExecutionStrategy(Agent agent, Communication.Envelope envelope) {
        super(agent, envelope);
    }

    @Override
    public void run() {
        
    }
    
}
