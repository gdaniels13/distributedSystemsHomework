Just about everything in the protocol definition has been implemented. The AI doesn't 
automatically throw bombs it just moves and collects resources. 

Also i have submitted a netbeans project. 

If you have any issues running the program contact me.

-Greg