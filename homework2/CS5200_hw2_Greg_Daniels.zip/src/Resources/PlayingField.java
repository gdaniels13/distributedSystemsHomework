package Resources;

/**
 * Created by gregor on 2/1/14.
 */
public class PlayingField extends Resource{
    public PlayingField(int id) {
        super(id);
    }

	public PlayingField(String id)
	{
		super(id);
	}
}
