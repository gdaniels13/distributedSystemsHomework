package Resources;

/**
 * Created by gregor on 2/1/14.
 */
public class Excuse extends Resource{
    protected Excuse(int id) {
        super(id);
    }

	public Excuse(String id)
	{
		super(id);
	}
}
