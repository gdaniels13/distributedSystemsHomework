package Resources;

public class Bomb extends Resource {
	public Whine[] whines;
    public Excuse[] excuses;
	public TimeTick tick;

    public Bomb(int id) {
        super(id);
    }
}