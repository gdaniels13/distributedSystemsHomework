package Resources;

/**
 * Created with IntelliJ IDEA.
 * User: Greg Daniels A00798340
 * Date: 2/5/14
 * Time: 10:06 AM
 */
public class FieldLayout extends Resource
{
	public FieldLayout(int id)
	{
		super(id);
	}

	public FieldLayout(String id)
	{
		super(id);
	}
}
