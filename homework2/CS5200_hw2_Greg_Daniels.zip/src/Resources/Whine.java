package Resources;

/**
 * Created by gregor on 2/1/14.
 */
public class Whine extends Resource {
    public Whine(String id) {
        super(id);
    }


}
