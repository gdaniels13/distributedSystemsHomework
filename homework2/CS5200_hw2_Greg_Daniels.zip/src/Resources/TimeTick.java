package Resources;

public class TimeTick extends Resource {
    public TimeTick(int id) {
        super(id);
    }
}