package Resources;

/**
 * Created by gregor on 2/1/14.
 */
public class Parameters extends Resource  {

	public Parameters(int id)
	{
		super(id);
	}

	public Parameters(String id)
	{
		super(id);
	}
}
