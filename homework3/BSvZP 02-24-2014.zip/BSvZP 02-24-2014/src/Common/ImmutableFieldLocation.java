package Common;

public class ImmutableFieldLocation extends  FieldLocation
{
    public ImmutableFieldLocation() 
    {
    	super(true);
    }
}