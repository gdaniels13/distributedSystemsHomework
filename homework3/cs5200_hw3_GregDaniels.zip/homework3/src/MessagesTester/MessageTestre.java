package MessagesTester;

import static org.junit.Assert.*;

import org.junit.Test;

import Common.*;
import Messages.*;

public class MessageTestre {

	@Test
	public void TestClassId()
	{
		/*ThreadsafeMessageQueue testQueue = new ThreadsafeMessageQueue();
		Message testMsg;

		assertEquals(0, testQueue.getCount());

		testMsg = new JoinGame();
		testQueue.enqueue(testMsg);

		Message msg = testQueue.dequeue();
		assertEquals(1, msg.getConversationId().SeqNumber);
		assertEquals(Message.MESSAGE_CLASS_IDS.JoinGame.getValue(), msg.getClassId()); // returns 1 (form base class), should be 102 from (derived class)
		

		assertTrue(testQueue.isEmpty());	*/
		
	}
	
	
}
