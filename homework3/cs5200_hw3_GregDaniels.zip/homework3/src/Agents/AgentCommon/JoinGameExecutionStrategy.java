package Agents.AgentCommon;

import Communication.Envelope;

/**
 * Created by gregor on 3/3/14.
 */
public class JoinGameExecutionStrategy extends ExecutionStrategy {

    public JoinGameExecutionStrategy(Agent agent, Envelope envelope) {
        super(agent,envelope);
    }

    @Override
    public void run() {

    }
}
