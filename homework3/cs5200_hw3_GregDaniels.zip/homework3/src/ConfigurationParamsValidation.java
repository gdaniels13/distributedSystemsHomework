import Agents.AgentCommon.Config;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;


/**
 * Created by gregor on 3/3/14.
 */
public class ConfigurationParamsValidation {
    @Test
    public void testGetConfigs() throws Exception {
        ArrayList<Config> configs= Main.getConfigs(new String[]{"configFile.txt"});
        assertEquals(configs.size(),6);
        assertEquals(configs.get(0).getaNumber(),"A00798340");
        assertEquals(configs.get(0).getFirstName(),"Greg");
        assertEquals(configs.get(5).getLocalPort(),10005);
    }

    @Test
    public void testValidateArgString() throws Exception {
        assert(Main.validateArgString("WG thingsforreasons.com 9876 10005 A00798340 Greg Daniels"));
        assertFalse(Main.validateArgString(" hello"));
        assertFalse(Main.validateArgString(null));
        assertFalse(Main.validateArgString(""));
        assertFalse(Main.validateArgString("# asdf"));
        assertFalse(Main.validateArgString("1 2 3 4 5 6 7 8 9"));
        assertFalse(Main.validateArgString("1 2 3 4 5 "));
    }
}
